<form method="post">
	<center><p>Esta seguro que desea eliminar esta categoria </p></center>
	<div class="cont-flex cont-just-cen"><button type="submit" class="btn btn-danger">SI</button>
	<button type="button" class="btn btn-success" data-dismiss="modal">NO</button></div>
	<input type="hidden" name="crud" value="del-cate">
	<input type="text" id="del-cate_cate_cod" name="cate_cod" >
</form>
