<form method="post">
	<center><p>Esta seguro que desea eliminar este usuario </p></center>
	<div class="cont-flex cont-just-cen"><button type="submit" class="btn btn-danger">SI</button>
	<button type="button" class="btn btn-success" data-dismiss="modal">NO</button></div>
	<input type="hidden" name="crud" value="del">
	<input type="hidden" id="del_usua_cod" name="usua_cod" >
</form>
