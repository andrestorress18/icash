<?php 
print('
</body>
<footer>
	
	<div class="vs-fot-copy">
	Copyright © iCash 2019 | UdeC - Universidad de Cundinamarca
	</div>
</footer>
</html>
');