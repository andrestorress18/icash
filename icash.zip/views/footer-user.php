<?php 
print('
			</div>
  		</div>	
  	</div>
</body>
<footer></footer>
<script src="./public/js/icash.js"></script>
</html>
');